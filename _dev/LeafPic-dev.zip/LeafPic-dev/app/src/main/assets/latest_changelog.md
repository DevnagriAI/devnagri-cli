v0.6-beta-1 
==================
- Fixed crash on startup and some random crash
- Fixed crash opening video (Nougat)
- fixed zoom out issue with SubScaling ImageView enabled
- Updated translations
- General improvements