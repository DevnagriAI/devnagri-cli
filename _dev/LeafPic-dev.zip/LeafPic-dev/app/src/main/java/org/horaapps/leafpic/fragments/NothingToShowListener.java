package org.horaapps.leafpic.fragments;

/**
 * Created by dnld on 12/16/17.
 */

public interface NothingToShowListener {
    void changedNothingToShow(boolean nothingToShow);
}
